import { Component } from '@angular/core';

@Component({
  standalone:true,
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ngdemo';

  add(a:number,b:number):number{
    return a+b;
  }
}
