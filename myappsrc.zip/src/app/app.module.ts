import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { AnotherComponent } from "./another.component";
import { AppComponent } from "./app.component";
import { GenderPipe } from "./gender.pipe";
import { MiscComponent } from "./misc.component";
import { NestedComponent } from "./nested.component";
import { TaxPipe } from "./tax.pipe";
import { TFormComponent } from "./tform.component";
import { RformComponent } from './rform/rform.component';
import { Ng14formComponent } from './ng14form/ng14form.component';
import { HttpClientModule } from '@angular/common/http';
import { CallapiComponent } from './callapi/callapi.component';

@NgModule({
    imports: [BrowserModule, FormsModule, ReactiveFormsModule, HttpClientModule],
    declarations: [AppComponent, AnotherComponent, NestedComponent,
        GenderPipe, TaxPipe, TFormComponent, MiscComponent, RformComponent, Ng14formComponent, CallapiComponent],
    bootstrap: [AppComponent, AnotherComponent]
})
export class AppModule { }