import { Component } from "@angular/core";

@Component({
    selector:'tform',
    template:`
    <h1>Template Form</h1>
    <h2>Hello {{name}}</h2>
    <form #empform="ngForm" (ngSubmit)="onSubmit(empform.value)">
        <input type="text" name="eid" placeholder="eid" required ngModel/><br/>
        <input type="text" name="ename" placeholder="ename" [(ngModel)]="name"/><br/>
        <input type="submit" [disabled]="empform.invalid"/>
    </form>
    `
})
export class TFormComponent{
    name:string='Abhishek'
    onSubmit(data:any){
        console.log(data)
    }
}