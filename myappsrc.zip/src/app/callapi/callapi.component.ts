import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-callapi',
  template: `
    <p>
      callapi works!
      {{users | json}}
    </p>
  `,
  styles: [
  ]
})
export class CallapiComponent implements OnInit {
  users:any;
  constructor(us:UserService) {
    us.getUsers().subscribe(u=>{this.users=u;console.log('next')},e=>console.log('my error'),()=>console.log('complete'));
  }

  ngOnInit(): void {
  }

}
