import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MyValidators } from '../myvalidators';

@Component({
  selector: 'app-rform',
  templateUrl: './rform.component.html',
  styleUrls: ['./rform.component.css']
})
export class RformComponent implements OnInit {
  emprform:FormGroup;
  /*emprform:FormGroup=new FormGroup({
    eid:new FormControl('',this.empidValidator),
    ename:new FormControl('',[Validators.required,
      Validators.pattern('[a-zA-Z]{2,10}')
    ])
  });*/

  constructor(fb:FormBuilder) //DI
  { 
    this.emprform=fb.group({
      eid:['',MyValidators.empidValidator],
      ename:['',Validators.required]
    });
  }

  mysetValue(){
    this.emprform.setValue({eid:101,ename:'Abhishek'});
  }

  mypatchValue(){
    this.emprform.patchValue({ename:'Gaurav'});
  }

  ngOnInit(): void {
  }
  onSubmit(data:any){
    console.log(data);
  }

  
}
