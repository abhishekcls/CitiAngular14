import { AbstractControl } from "@angular/forms";

export class MyValidators{
    static empidValidator(c:AbstractControl){
        if(!c.value)
          return null;
        
          let id=c.value;
          let min=101,max=155;
    
          if(id>=min && id<=max)
            return null
          else
            return {'veid':{'min':min,'max':max}}
      }
}