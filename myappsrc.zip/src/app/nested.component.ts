import { Component, EventEmitter, Input, Output } from "@angular/core";

@Component({
    selector:'nested',
    template:`<h2>Nested</h2>{{emp|json}}
    <button (click)="ctp()">ctp</button>
    `
})
export class NestedComponent{
    @Input() emp:any;

    @Output()
    childEvent=new EventEmitter();

    ctp(){
        this.childEvent.emit(this.emp.ename);
    }
}