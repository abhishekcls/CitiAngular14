import { Component } from "@angular/core";

@Component({
    selector:'another',
    templateUrl:'another.component.html',
    styleUrls:['another.component.css']
})
export class AnotherComponent{
}