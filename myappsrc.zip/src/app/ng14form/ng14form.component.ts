import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-ng14form',
  template: `
    <p>
      ng14form works!
    </p>
  `,
  styles: [
  ]
})
export class Ng14formComponent implements OnInit {

  emprform:FormGroup=new FormGroup({
    eid:new FormControl<number | null>(null,Validators.required),
    ename:new FormControl()
  });

  constructor() { 
  }

  ngOnInit(): void {
  }

}
