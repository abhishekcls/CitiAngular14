import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  onSubmit(data:any){
    //console.log(data)
    if(data.uname=='abhishek' && data.pass=='12345')
    {
      alert('Login success');
      localStorage.setItem('user',data.uname);
    }
    else{
      alert('Login failure')
    }
  }
}
